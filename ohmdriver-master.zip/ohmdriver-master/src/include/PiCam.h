#pragma once
#if DEFINED(RASPBERRY)
#include <Config.h>
#include <queue>
#include <memory>
#include <list>
#include <functional>
#include <atomic>
#include <thread>
#include <vector>
#include <string>
#include <ICamera.h>

#include <libcamera/libcamera.h>
#include <condition_variable>


class PiCam : public ICamera
{
    std::shared_ptr<libcamera::CameraManager> cameraManager;
    std::shared_ptr<libcamera::Camera> camera;
    std::queue<libcamera::Request *> requestQueue;
    std::unique_ptr<libcamera::CameraConfiguration> config;
    std::unique_ptr<libcamera::FrameBufferAllocator> allocator;
    libcamera::ControlList controls;
    std::vector<std::unique_ptr<libcamera::Request>> requests;
    std::map<libcamera::FrameBuffer *, std::vector<libcamera::Span<uint8_t>>> mapped_buffers;

    std::condition_variable newImage;

    std::thread camThread;
    std::atomic_bool threadRunning;
    std::atomic_bool cameraRunning;

    PiCam();    

public:
    friend class CameraCreator;
    std::list<std::function<void(void)>> queue;

    PiCam(PiCam const &) = delete;
    void operator=(PiCam const &) = delete;

    //static PiCam *getInstance();

    void processRequest(libcamera::Request *request);

    void init();
    bool wasInitSuccessful();
    void start();
    void stop();
    void cameraLoop();
};
#endif