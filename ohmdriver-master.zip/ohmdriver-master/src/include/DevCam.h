#pragma once
#include <Config.h>
#include <queue>
#include <memory>
#include <list>
#include <functional>
#include <atomic>
#include <thread>
#include <vector>
#include <string>
#include <ICamera.h>

class DevCam : public ICamera
{
    std::vector<std::string> imageNames;
    std::vector<std::vector<uint8_t>> images;
    std::thread camThread;
    std::atomic_bool threadRunning;
    std::atomic_bool cameraRunning;

    DevCam();    

public:
    friend class CameraCreator;
    std::list<std::function<void(void)>> queue;

    DevCam(DevCam const &) = delete;
    void operator=(DevCam const &) = delete;

    static DevCam *getInstance();

    void init();
    bool wasInitSuccessful();
    void start();
    void stop();
    void cameraLoop();
};