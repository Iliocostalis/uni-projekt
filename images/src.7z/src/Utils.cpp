#include <Utils.h>

std::condition_variable stop;
bool isPreviewVisible = false;
bool areLinesVisible = false;
SimpleWindow* window = nullptr;